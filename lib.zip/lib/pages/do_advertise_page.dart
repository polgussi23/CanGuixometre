import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'add_users_to_photo_page.dart'; // Importa la pàgina de selecció

class DoAdvertisePage extends StatefulWidget {
  @override
  _DoAdvertisePageState createState() => _DoAdvertisePageState();
}

class _DoAdvertisePageState extends State<DoAdvertisePage> {
  DateTime selectedDate = DateTime.now();
  String selectedMeal = 'sopar';
  List<String> participants = [];
  TimeOfDay? selectedTime; // Nuevo campo para la hora
  bool noTimeSelected = false; // Para la opción "aun no lo tengo claro"

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now().subtract(Duration(days: 365)),
      lastDate: DateTime.now().add(Duration(days: 365)),
      locale: const Locale('ca', 'ES'),
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        selectedTime = picked;
        noTimeSelected = false;
      });
    }
  }

  Future<void> _selectParticipants() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddUsersToPhotoPage(
          title: "QUÍ VE SEGUR A L'ÀPAT?",
          selectedParticipants: participants,
        ),
      ),
    );
    if (result != null && result is List<String>) {
      setState(() {
        participants = result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    String horaText;
    if (noTimeSelected) {
      horaText = "Encara no ho tinc clar";
    } else if (selectedTime != null) {
      horaText = selectedTime!.format(context);
    } else {
      horaText = "No seleccionada";
    }

    return Scaffold(
      appBar: AppBar(title: Text('Avís de nou àpat')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Escull un dia:', style: TextStyle(fontSize: 16)),
            Row(
              children: [
                Text(
                  DateFormat('dd/MM/yyyy').format(selectedDate),
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                SizedBox(width: 16),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                  ),
                  onPressed: () => _selectDate(context),
                  child: Text('Canvia'),
                ),
              ],
            ),
            SizedBox(height: 24),
            Text('Escull hora:', style: TextStyle(fontSize: 16)),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Text(
                    horaText,
                    style: TextStyle(fontSize: 18),
                  ),
                  SizedBox(width: 16),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                    ),
                    onPressed: () => _selectTime(context),
                    child: Text('Selecciona hora'),
                  ),
                  SizedBox(width: 8),
                  TextButton(
                    onPressed: () {
                      setState(() {
                        selectedTime = null;
                        noTimeSelected = true;
                      });
                    },
                    child: Text("Encara no ho tinc clar"),
                  ),
                ],
              ),
            ),
            SizedBox(height: 24),
            Text('Escull àpat:', style: TextStyle(fontSize: 16)),
            Row(
              children: [
                ChoiceChip(
                  label: Text('Dinar', style: TextStyle(color: selectedMeal == 'dinar' ? Colors.black : null)),
                  selected: selectedMeal == 'dinar',
                  selectedColor: Colors.lightBlue[100],
                  checkmarkColor: Colors.black,
                  onSelected: (selected) {
                    setState(() {
                      selectedMeal = 'dinar';
                    });
                  },
                ),
                SizedBox(width: 8),
                ChoiceChip(
                  label: Text('Sopar', style: TextStyle(color: selectedMeal == 'sopar' ? Colors.black : null)),
                  selected: selectedMeal == 'sopar',
                  selectedColor: Colors.lightBlue[100],
                  checkmarkColor: Colors.black,
                  onSelected: (selected) {
                    setState(() {
                      selectedMeal = 'sopar';
                    });
                  },
                ),
              ],
            ),
            SizedBox(height: 24),
            Text('Participants:', style: TextStyle(fontSize: 16)),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(horizontal: 30),
              ),
              icon: Icon(Icons.group),
              label: Text('Selecciona participants'),
              onPressed: _selectParticipants,
            ),
            SizedBox(height: 8),
            Wrap(
              spacing: 8.0,
              children: participants
                  .map((p) => Chip(label: Text(p)))
                  .toList(),
            ),
            SizedBox(height: 24),
            Center(
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  print('Día: $selectedDate');
                  print('Hora: ${noTimeSelected ? "Encara no ho tinc clar" : (selectedTime != null ? selectedTime!.format(context) : "No seleccionada")}');
                  print('Àpat: $selectedMeal');
                  print('Participants: $participants');
                },
                child: Text('Confirmar'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}