import 'dart:io';
import 'package:can_guix/pages/do_advertise_page.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:can_guix/services/api_service.dart';
import 'package:can_guix/services/user_provider.dart';

class NewMealAdvertisePage extends StatefulWidget {
  const NewMealAdvertisePage({Key? key}) : super(key: key);

  @override
  _NewMealAdvertisePageState createState() => _NewMealAdvertisePageState();
}

class _NewMealAdvertisePageState extends State<NewMealAdvertisePage> {
  late int? _userId;

  @override
  void initState() {
    super.initState();
    final userProvider = Provider.of<UserProvider>(context, listen: false);

    // Carregar les dades de l'usuari al principi
    _loadUserProfile(userProvider);
  }

  Future<void> _loadUserProfile(UserProvider userProvider) async {
    try {
      // Espera que el provider carregui les dades de l'usuari
      await userProvider.getUserInfo(); // Si tens una funció per carregar les dades
      
      //final nom = userProvider.nom;
      _userId = userProvider.id;
      final nom = await  ApiService.getUserName(_userId!);

      // Carregar la imatge de perfil
      //await _loadUserProfileImage(nom.toString());
      //_nameController = TextEditingController(text: userProvider.nom);
    } catch (e) {
      print("Error al carregar les dades de l'usuari: $e");
    }
  }
  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<UserProvider>(context);

    return Scaffold(
      appBar: AppBar(title: Text('VOLS ANAR A CAN GUIX?')), 
      body: 
      Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: 40),
          Center(
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black, backgroundColor: Colors.lightGreenAccent,
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 10),
              ),
              icon: Icon(Icons.campaign),
              label: Text("AVISA!"),
                onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DoAdvertisePage(),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

}
