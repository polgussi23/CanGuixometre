// photo_gallery_page.dart
//import 'dart:typed_data';
import 'package:can_guix/pages/edit_photo_page.dart';
import 'package:can_guix/pages/no_score_gallery_page.dart';
import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'upload_photo_page.dart';
import '../services/api_service.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:can_guix/services/user_provider.dart';
import 'package:provider/provider.dart';

class PhotoGalleryPage extends StatefulWidget {
  const PhotoGalleryPage({super.key});

  @override
  _PhotoGalleryPageState createState() => _PhotoGalleryPageState();
}

class _PhotoGalleryPageState extends State<PhotoGalleryPage> {
  final List<ImageData> uploadedImages = [];
  dynamic _selectedImage;
  bool isLoading = false;  // Indica si estem carregant imatges
  int currentPage = 1;  // Pàgina actual de la paginació
  int imagesPerPage = 8;
  List<int> imagesNoScore = [];
  
  @override
  void initState() {
    super.initState();
    _loadImages();  // Carregar les primeres imatges al iniciar la pàgina
    _imatgesSensePuntuacio();
  }

  Future<void> _loadImages() async {
    setState(() {
      isLoading = true;
    });

    try {
      List<ImageData> newImages =  await ApiService.getImages(currentPage, imagesPerPage);
      //<Uint8List> newImages = await ApiService.getImages(currentPage, 5); // Funció per obtenir imatges
      setState(() {
        uploadedImages.addAll(newImages);
        currentPage++; // Incrementa la pàgina per a la pròxima càrrega
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }
  
  void showImageSourceOptions() async {
    final ImageSource? source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (BuildContext context) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: Icon(Icons.camera),
              title: Text('Fer una foto'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: Icon(Icons.photo_library),
              title: Text('Triar de la galeria'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
          ],
        );
      },
    );

    if (source != null) {
      final pickedFile = await ImagePicker().pickImage(source: source);
      if (pickedFile != null) {
        setState(() {
          if(!kIsWeb){
            _selectedImage = File(pickedFile.path);
          }else{
            _selectedImage = pickedFile.readAsBytes();
          }
        });
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => UploadPhotoPage(selectedImage: _selectedImage),
          ),
        );
      }
    }
  }

  Future<void> _imatgesSensePuntuacio() async{
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    //int n;
    await userProvider.getUserInfo();
    List<dynamic> response = await ApiService.getNonScoreImagesUser(userProvider.id);
    //nImgesNoScore = response.length;
    for(var imatges in response){
      //print(imatges);
      imagesNoScore.add(imatges['imatge_id']);
    }
  }

  @override
  Widget build(BuildContext context){
    //var number = _imatgesSensePuntuacio();
    return Scaffold(
      appBar: AppBar(
        //title: Text('GALERIA'),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //mainAxisSize: MainAxisSize.min,
          children: [
            Text("GALERIA"),
            //SizedBox(width: 8),
              if(imagesNoScore.length > 0)
              Transform.translate(
              offset: Offset(-30, 0),
              child: Stack(
                clipBehavior: Clip.none,
                //alignment: Alignment.center,
                children: [
                  Positioned(
                  //right:0,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context, 
                          MaterialPageRoute(builder: (context) => NoScoreGalleryPage(imagesList: imagesNoScore,)),
                        );
                      },
                      child: Icon(
                        Icons.warning,
                        color: Colors.yellow,
                        size:34,
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: -6,
                    child: Container(
                      padding: EdgeInsets.all(3),
                      constraints: BoxConstraints(
                        minWidth: 16, // Amplada mínima per mantenir un cercle estètic
                        minHeight: 16, // Alçada mínima
                        maxWidth: 20, // Amplada màxima
                        maxHeight: 20, // Alçada màxima
                      ),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          imagesNoScore.length.toString(), // Aquí poses el número dinàmic
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20, // Mida més gran quan és d’una xifra
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],)
      ),
      body: Center(
        child: uploadedImages.isNotEmpty
            ? NotificationListener<ScrollNotification>(
                onNotification: (ScrollNotification scrollInfo) {
                  if (!isLoading &&
                      scrollInfo.metrics.pixels == scrollInfo.metrics.maxScrollExtent) {
                    _loadImages(); // Carregar més imatges quan arribem al final
                    return true;
                  }
                  return false;
                },
                child: GridView.builder(
                  padding: EdgeInsets.all(8), // Espai al voltant de la quadrícula
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, // Ara cada fila tindrà dues imatges
                    mainAxisSpacing: 20, // Espai vertical entre les imatges
                    crossAxisSpacing: 8, // Espai horitzontal entre les imatges
                    childAspectRatio: 1, // Fa que les imatges siguin quadrades
                  ),
                  itemCount: uploadedImages.length,
                  itemBuilder: (context, index) {
                    String formattedDate = DateFormat('dd/MM/yyyy').format(uploadedImages[index].createdAt);
                    return GestureDetector(
                      onTap: () {
                        // Navega a la pàgina upload_photo_page i passa la ID de la imatge
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => EditPhotoPage(selectedImage: uploadedImages[index]),
                          ),
                        );
                      },
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          SizedBox(
                            height: MediaQuery.of(context).size.width * 0.4, // Ajusta a un 40% de l'amplada de la pantalla
                            width: MediaQuery.of(context).size.width * 0.4,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8), // Cantonades arrodonides
                              child: Image.memory(
                                uploadedImages[index].image,
                                fit: BoxFit.cover, // Omple el contenidor de manera uniforme
                              ),
                            ),
                          ),
                          SizedBox(height: 6), // Espai entre la imatge i la data
                          Text(
                            formattedDate,
                            style: TextStyle(fontSize: 14, color: Colors.grey), // Estil del text
                          ),
                        ],
                      ),
                    );
                  },
                ),
              )
            : isLoading
                ? CircularProgressIndicator() // Mostra el cercle de càrrega mentre carrega imatges
                : Text('Encara no hi ha imatges pujades.'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showImageSourceOptions(),
        tooltip: 'Pujar Imatge',
        backgroundColor: Color.fromARGB(255, 251, 255, 0), // Tooltip per indicar la funcionalitat
        child: Icon(Icons.upload_file, color: Colors.black,),
      ),
    );
  }
}
